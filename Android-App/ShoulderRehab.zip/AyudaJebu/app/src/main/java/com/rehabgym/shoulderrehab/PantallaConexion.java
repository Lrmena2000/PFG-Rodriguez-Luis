package com.rehabgym.shoulderrehab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PantallaConexion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_conexion);
    }
}