package com.rehabgym.shoulderrehab;
import android.app.Application;


import com.ingenieriajhr.blujhr.BluJhr;


public class GlobalClass extends Application{

    public static int habilitador = 0;
    public static String id="id";
    public static String nombre = "nombre";
    public static String dato = "none";

    public static BluJhr blue; // Objeto general utilizado en el transcurso del codigo

}
