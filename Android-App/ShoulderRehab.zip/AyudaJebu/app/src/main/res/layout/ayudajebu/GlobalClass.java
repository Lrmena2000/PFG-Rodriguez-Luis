package layout.ayudajebu;
import android.app.Application;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.animation.ObjectAnimator;
import android.widget.ImageView;


import com.ingenieriajhr.blujhr.BluJhr;

import java.util.ArrayList;
import java.util.List;


public class GlobalClass extends Application{

    public static int habilitador = 0;
    public static String id="id";
    public static String nombre = "nombre";
    public static String dato = "none";

    public static BluJhr blue; // Objeto general utilizado en el transcurso del codigo

}
