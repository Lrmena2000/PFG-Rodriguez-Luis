package com.rehabgym.shoulderrehab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Instrucciones extends AppCompatActivity {

    // Elementos a utilizar:
    Button volver1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Crear la ventana y ocultar la barra de navegación:
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);


        // Se crea la ventana:
        setContentView(R.layout.activity_instrucciones);

        // Objetos pertenecientes a la pantalla:
        volver1 = (Button) findViewById(R.id.volver1);


        // Acciones de los objetos:
        volver1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Se cierran todas la ventanas y se vuelve al menu:
                Intent intent = new Intent(getApplicationContext(), Menu.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish(); // Se cierra la actividad actual
            }
        });


    }
}