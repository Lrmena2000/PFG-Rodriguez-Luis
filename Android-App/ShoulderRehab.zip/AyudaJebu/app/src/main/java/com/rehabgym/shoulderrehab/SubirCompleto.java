package com.rehabgym.shoulderrehab;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.MimeTypeMap;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class SubirCompleto extends AppCompatActivity {

    private StorageReference storageReference;
    private ProgressDialog progressDialog;

    private static final int PICK_FILE_REQUEST = 1;
    private Uri fileUri;
    String local_id;
    String local_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subir_completo);

        // Obtener los datos enviados por el Intent
        Intent intent = getIntent();
        if (intent != null) {
            local_name = getIntent().getStringExtra("nombre_env");
            local_id = getIntent().getStringExtra("id_env");

            GlobalClass.id = local_id;
            GlobalClass.nombre = local_name;
        }

        progressDialog = new ProgressDialog(this);
        storageReference = FirebaseStorage.getInstance().getReference(); // Apunta al directorio raíz

        // Abre la ventana de selección de archivos automáticamente al iniciar la actividad.
        openFileChooser();
    }

    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*"); // Puedes especificar el tipo de archivo que deseas permitir aquí
        startActivityForResult(intent, PICK_FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            fileUri = data.getData();
            uploadFile();
        } else {
            // Manejar el caso en el que el usuario no selecciona un archivo y cerrar la actividad si es necesario.
            // Crear un Intent y agregar los datos como "extras"
            Intent intent = new Intent(SubirCompleto.this, ManejoDatos.class);
            intent.putExtra("id_env", GlobalClass.id);
            intent.putExtra("nombre_env", GlobalClass.nombre);
            intent.putExtra("habil", 1);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
    }

    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private void uploadFile() {
        if (fileUri != null) {
            progressDialog.setMessage("Subiendo archivo...");
            progressDialog.show();

            // Nombre de la carpeta que deseas verificar y crear si no existe
            String carpetaNombre = local_id;

            // Crea una referencia a la carpeta
            StorageReference carpetaReference = storageReference.child(carpetaNombre);

            carpetaReference.listAll()
                    .addOnSuccessListener(listResult -> {
                        // La carpeta existe, sube el archivo directamente
                        StorageReference fileReference = carpetaReference.child(System.currentTimeMillis()
                                + "." + getFileExtension(fileUri));

                        fileReference.putFile(fileUri)
                                .addOnSuccessListener(taskSnapshot -> {
                                    progressDialog.dismiss();
                                    Toast.makeText(SubirCompleto.this, "Archivo subido exitosamente", Toast.LENGTH_LONG).show();
                                    // Cierra la actividad después de cargar el archivo.
                                    Intent intent = new Intent(SubirCompleto.this, ManejoDatos.class);
                                    intent.putExtra("id_env", GlobalClass.id);
                                    intent.putExtra("nombre_env", GlobalClass.nombre);
                                    intent.putExtra("habil", 1);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                })
                                .addOnFailureListener(e -> {
                                    progressDialog.dismiss();
                                    Toast.makeText(SubirCompleto.this, "Error al subir el archivo: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                    // Cierra la actividad en caso de error.
                                    Intent intent = new Intent(SubirCompleto.this, ManejoDatos.class);
                                    intent.putExtra("id_env", GlobalClass.id);
                                    intent.putExtra("nombre_env", GlobalClass.nombre);
                                    intent.putExtra("habil", 1);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                });
                    })
                    .addOnFailureListener(e -> {
                        // La carpeta no existe, créala y luego sube el archivo
                        carpetaReference.putFile(fileUri)
                                .addOnSuccessListener(taskSnapshot -> {
                                    progressDialog.dismiss();
                                    Toast.makeText(SubirCompleto.this, "Archivo subido exitosamente", Toast.LENGTH_LONG).show();
                                    // Cierra la actividad después de cargar el archivo.
                                    Intent intent = new Intent(SubirCompleto.this, ManejoDatos.class);
                                    intent.putExtra("id_env", GlobalClass.id);
                                    intent.putExtra("nombre_env", GlobalClass.nombre);
                                    intent.putExtra("habil", 1);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                })
                                .addOnFailureListener(e1 -> {
                                    progressDialog.dismiss();
                                    Toast.makeText(SubirCompleto.this, "Error al subir el archivo: " + e1.getMessage(), Toast.LENGTH_LONG).show();
                                    // Cierra la actividad en caso de error.
                                    Intent intent = new Intent(SubirCompleto.this, ManejoDatos.class);
                                    intent.putExtra("id_env", GlobalClass.id);
                                    intent.putExtra("nombre_env", GlobalClass.nombre);
                                    intent.putExtra("habil", 1);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intent);
                                });
                    });
        } else {
            Toast.makeText(this, "No se ha seleccionado un archivo", Toast.LENGTH_SHORT).show();
            // Cierra la actividad si no se seleccionó un archivo.
            Intent intent = new Intent(SubirCompleto.this, ManejoDatos.class);
            intent.putExtra("id_env", GlobalClass.id);
            intent.putExtra("nombre_env", GlobalClass.nombre);
            intent.putExtra("habil", 1);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
    }
}
