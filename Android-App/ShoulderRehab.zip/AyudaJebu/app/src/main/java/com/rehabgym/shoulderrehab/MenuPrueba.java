package com.rehabgym.shoulderrehab;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.ingenieriajhr.blujhr.BluJhr;

import java.util.ArrayList;
import java.util.List;


public class MenuPrueba extends AppCompatActivity {

    // Elementos a utilizar:

    BluJhr blue; // Objeto general utilizado en el transcurso del codigo
    List<String> requiredPermissions;
    ArrayList<String> devicesBluetooth = new ArrayList<String>(); // Guarda los elementos BT vinculados
    LinearLayout viewConn;
    ListView listDeviceBluetooth;
    Button accept_btn;
    Button recibir_datos;
    EditText voltage_txt;
    EditText angle_txt;
    Button return_btn;
    TextView textView4;
    TextView textView8;
    TextView voltView;

    String nombre;
    String ID;

    int length_angle = 0;
    int length_voltage = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Crear la ventana y ocultar la barra de navegación
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);


        // Se crea la ventana:
        setContentView(R.layout.activity_menu_prueba);

        // Obtener los datos enviados por el Intent
        Intent intent = getIntent();
        if (intent != null) {
            nombre = getIntent().getStringExtra("nombre_env");
            ID = getIntent().getStringExtra("id_env");
        }

        // Se inicializa el objeto como parte de la clase de bluetooth
        blue = new BluJhr(this);
        blue.onBluetooth();


        // Objetos pertenecientes a la pantalla:
        accept_btn = (Button) findViewById(R.id.accept_btn);
        voltage_txt = (EditText) findViewById(R.id.voltage_txt);
        angle_txt = (EditText) findViewById(R.id.angle_txt);
        return_btn = (Button) findViewById(R.id.return_btn);
        listDeviceBluetooth = findViewById(R.id.listDeviceBluetooth);
        textView4 = findViewById(R.id.textView4);
        textView8 = findViewById(R.id.textView8);
        voltView = findViewById(R.id.voltView);
        recibir_datos = findViewById(R.id.recibir_datos);





        // Acciones de los objetos:
        // Botón de aceptar datos
        accept_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Se guardan los datos de los editText:
                String angulo_ingresado = angle_txt.getText().toString();
                String voltaje_ingresado = voltage_txt.getText().toString();

                //PONER AQUI CODIGO DE BLUETOOTH PARA ENVIAR DATOS
                blue.bluTx("n"+angulo_ingresado+voltaje_ingresado+"o");
            }
        });
        // Botón de regresar:
        return_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try{
                    blue.closeConnection();
                    Intent intent = new Intent(MenuPrueba.this, Menu.class);
                    intent.putExtra("id_env", GlobalClass.id);
                    intent.putExtra("nombre_env", GlobalClass.nombre);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
                catch (Exception e){
                    // Se cierran todas la ventanas y se vuelve al menu:
                    Intent intent = new Intent(MenuPrueba.this, Menu.class);
                    intent.putExtra("id_env", GlobalClass.id);
                    intent.putExtra("nombre_env", GlobalClass.nombre);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }

            }
        });

        recibir_datos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                blue.bluTx("m"); // CAMBIAR POR LA LETRA QUE ES
                accept_btn.setVisibility(View.VISIBLE);
                recibir_datos.setVisibility(View.GONE);

            }
        });




        // Cuadros de ingreso: Si no se cumplen las condiciones de nombre y ID correctos, no se habilita el botón de aceptar
        // Cuadro de ingreso de nombre:
        angle_txt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                String inputText1 = s.toString();
                length_angle = inputText1.length();
                boolean isButtonEnabled1 = (length_angle == 2) && (length_voltage ==4) &&(Integer.valueOf(inputText1)<=90);
                accept_btn.setEnabled(isButtonEnabled1);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });



        // Cuadro de ingreso de ID:
        voltage_txt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence n, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence n, int i, int i1, int i2) {

                String inputText2 = n.toString();
                length_voltage = inputText2.length();
                boolean isButtonEnabled2 = (length_angle == 2) && (length_voltage ==4) &&(Integer.valueOf(inputText2)<=1023);
                accept_btn.setEnabled(isButtonEnabled2);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });



// ************************************INICIO DE BLUETOOTH********************************************************************************************* //
        // Se conecta el modulo:

        listDeviceBluetooth.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (!devicesBluetooth.isEmpty()){
                    blue.connect(devicesBluetooth.get(i));
                    blue.setDataLoadFinishedListener(new BluJhr.ConnectedBluetooth() {
                        @Override
                        public void onConnectState(@NonNull BluJhr.Connected connected) {
                            if (connected == BluJhr.Connected.True){
                                Toast.makeText(getApplicationContext(),"Conectado",Toast.LENGTH_SHORT).show();
                                listDeviceBluetooth.setVisibility(View.GONE); // Se apaga el listview
                                textView4.setVisibility(View.VISIBLE);
                                textView8.setVisibility(View.VISIBLE);
                                voltage_txt.setVisibility(View.VISIBLE);
                                angle_txt.setVisibility(View.VISIBLE);
                                recibir_datos.setVisibility(View.VISIBLE);
                                return_btn.setVisibility(View.VISIBLE);
                                voltView.setVisibility(View.VISIBLE);

                                RecibirDatos();
                            }else{
                                if (connected == BluJhr.Connected.Pending){
                                    Toast.makeText(getApplicationContext(),"Conectando",Toast.LENGTH_SHORT).show();
                                }else{
                                    if (connected == BluJhr.Connected.False){
                                        Toast.makeText(getApplicationContext(),"No se pudo conectar, intente de nuevo",Toast.LENGTH_SHORT).show();
                                    }else{
                                        if (connected == BluJhr.Connected.Disconnect){
                                            Toast.makeText(getApplicationContext(),"Desconectado",Toast.LENGTH_SHORT).show();
                                            listDeviceBluetooth.setVisibility(View.VISIBLE);
                                            viewConn.setVisibility(View.GONE);
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            }
        });


    }

    // Se piden permisos BT para Android 12 o más y para poder guardar archivos
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (blue.checkPermissions(requestCode,grantResults)){
            Toast.makeText(this, "Exit", Toast.LENGTH_SHORT).show();
            blue.initializeBluetooth();
        }else{
            if(Build.VERSION.SDK_INT < Build.VERSION_CODES.S){
                blue.initializeBluetooth();
            }else{
                Toast.makeText(this, "Algo salio mal", Toast.LENGTH_SHORT).show();
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    // Captura si el usuario dio o no permiso para prender el BT
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (!blue.stateBluetoooth() && requestCode == 100){
            blue.initializeBluetooth();
        }else{
            if (requestCode == 100){
                devicesBluetooth = blue.deviceBluetooth();
                if (!devicesBluetooth.isEmpty()){
                    ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_expandable_list_item_1,devicesBluetooth);
                    listDeviceBluetooth.setAdapter(adapter); // Se conecta el dispositivo
                }else{
                    Toast.makeText(this, "No tienes vinculados dispositivos", Toast.LENGTH_SHORT).show();
                }

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }


    // Recibir datos
    private void RecibirDatos() {
        blue.loadDateRx(new BluJhr.ReceivedData() {
            @Override
            public void rxDate(@NonNull String s) {
                    voltView.setText(s);
            }

        });

    }
// ************************************************FIN DE BLUETOOTH************************************************************** //




}

