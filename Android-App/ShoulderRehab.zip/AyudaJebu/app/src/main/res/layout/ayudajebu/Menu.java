package layout.ayudajebu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.rehabgym.shoulderrehab.R;

public class Menu extends AppCompatActivity {

    // Elementos a utilizar en la ventana:
    Button extension_btn;
    Button compresion_btn;
    Button exit_btn;
    Button data_btn;
    Button inst_btn;
    Button upload_btn;
    TextView visualizador;

    String Dato;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Crear la ventana y ocultar la barra de navegación
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        // Emepezar a correr la ventana:
        setContentView(R.layout.activity_menu);



        // Obtener los datos enviados por el Intent
        Intent intent = getIntent();
        if (intent != null) {
            Dato = intent.getStringExtra("ID");
        }

        // Elementos dentro de la ventana que se crean al crear la ventana:
        extension_btn = (Button) findViewById(R.id.extension_btn);
        compresion_btn = (Button) findViewById(R.id.flexion_btn);
        exit_btn = (Button) findViewById(R.id.exit_btn);
        data_btn = (Button) findViewById(R.id.data_btn);
        inst_btn = (Button) findViewById(R.id.inst_btn);
        upload_btn = (Button) findViewById(R.id.upload_btn);
        visualizador = (TextView) findViewById(R.id.visualizador);

        try{
            Integer.valueOf(Dato);
            GlobalClass.habilitador = 1;
            GlobalClass.id = Dato;
        }

        catch (Exception e){

        }

        if (GlobalClass.habilitador == 0){
            extension_btn.setEnabled(false);
            compresion_btn.setEnabled(false);
            upload_btn.setEnabled(false);
        }
        else{
            extension_btn.setEnabled(true);
            compresion_btn.setEnabled(true);
            upload_btn.setEnabled(true);
        }

        // Acciones de los elementos:
        upload_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try{
                    int kk = Integer.valueOf(Dato);
                    GlobalClass.id = Dato;
                    Intent i = new Intent(Menu.this,ManejoDatos.class);
                    startActivity(i);
                }

                catch (Exception e){
                    Intent i = new Intent(Menu.this,ManejoDatos.class);
                    startActivity(i);
                }



            }
        });

        extension_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(Menu.this,JuegoExtension.class);
                startActivity(i);
            }
        });

        exit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });

        data_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Menu.this,IngresoDatos.class);
                startActivity(i);
            }
        });

        inst_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Menu.this,MenuPrueba.class);
                intent.putExtra("ID", GlobalClass.id);
                startActivity(i);
            }
        });

        visualizador.setText(Dato);

    }

    // Para no poder utilizar el botón de atrás del teléfono:
    @Override
    public void onBackPressed(){
        Toast.makeText(Menu.this," Función no permitida, favor utilizar el botón de salir",Toast.LENGTH_SHORT).show();
    }

}