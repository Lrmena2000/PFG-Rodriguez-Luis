package com.rehabgym.shoulderrehab;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.animation.ObjectAnimator;
import android.widget.ImageView;


import com.ingenieriajhr.blujhr.BluJhr;

import java.util.ArrayList;
import java.util.List;

import android.text.Editable;
import android.text.TextWatcher;


import android.content.pm.PackageManager;


public class JuegoFlexion extends AppCompatActivity {

    // Variables a utilizar en este juego
    private ImageView carro;
    private int screenWidth;
    List<String> angulo = new ArrayList<>();
    List<String> fecha = new ArrayList<>();
    int control = 0;
    int salida = 0;
    int ejercicio = 0; // Flexion


    // Elementos a utilizar:
    private static final int REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE = 1; // Para manejar los permisos de escritura
    BluJhr blue; // Objeto general utilizado en el transcurso del codigo
    List<String> requiredPermissions;
    ArrayList<String> devicesBluetooth = new ArrayList<String>(); // Guarda los elementos BT vinculados
    LinearLayout viewConn;
    ListView listDeviceBluetooth;
    Button buttonSend;
    Button start;
    Button stop;
    TextView consola;
    TextView porcentTxt;
    EditText ang_meta;
    Button  Accept_btn;
    EditText Resorte;
    Button  Accept_btn2;

    Button  izq_btn;
    Button  der_btn;
    Button  flex_btn;
    Button  ext_btn;

    TextView angulotxt;

    TextView brazotxt;
    TextView resortetxt;

    TextView repView;
    TextView repTxt;

    TextView metaView;
    TextView metaTxt;
    TextView porcentView;


    String local_id = GlobalClass.id;
    String nombre;
    String ID;
    int porcentaje;

    int rep_correctas = 0;
    int habilitador_reps = 0;
    int angulo_mayor_reps = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Crear la ventana y ocultar la barra de navegación
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        // Se crea la ventana:
        setContentView(R.layout.activity_juego_flexion);


        // Obtener los datos enviados por el Intent
        Intent intent = getIntent();
        if (intent != null) {
            nombre = getIntent().getStringExtra("nombre_env");
            ID = getIntent().getStringExtra("id_env");
        }

        // Se inicializa el objeto como parte de la clase de bluetooth
        blue = new BluJhr(this);
        blue.onBluetooth();

        // Objetos pertenecientes a la pantalla:

        listDeviceBluetooth = findViewById(R.id.listDeviceBluetooth);
        buttonSend = findViewById(R.id.buttonSend);
        consola = findViewById(R.id.consola);
        start = findViewById(R.id.start_btn);
        stop = findViewById(R.id.stop_btn);
        ang_meta = findViewById(R.id.voltage_txt);
        Accept_btn = findViewById(R.id.Accept_btn);
        Resorte = findViewById(R.id.Resorte);
        Accept_btn2 = findViewById(R.id.Accept_btn2);
        angulotxt = findViewById(R.id.angulotxt);
        resortetxt = findViewById(R.id.resortetxt);
        carro = findViewById(R.id.carro);
        screenWidth = getResources().getDisplayMetrics().widthPixels;
        repView = findViewById(R.id.repView);
        repTxt = findViewById(R.id.repTxt);
        metaView = findViewById(R.id.metaView);
        metaTxt = findViewById(R.id.metaTxt);
        porcentTxt = findViewById(R.id.porcentTxt);
        porcentView = findViewById(R.id.porcentView);
        brazotxt = findViewById(R.id.brazotxt);
        izq_btn = findViewById(R.id.izq_btn);
        der_btn = findViewById(R.id.der_btn);
        flex_btn = findViewById(R.id.flex_btn);
        ext_btn = findViewById(R.id.ext_btn);

//**************************************ACCIONES DE LOS OBJETOS****************************************//

        Resorte.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence n, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence n, int i, int i1, int i2) {

                String inputText1 = n.toString();
                int length_resorte = inputText1.length();
                boolean isButtonEnabled = (length_resorte == 1);
                Accept_btn2.setEnabled(isButtonEnabled);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        ang_meta.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence n, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence n, int i, int i1, int i2) {

                String inputText2 = n.toString();
                int length_angulo = inputText2.length();
                int condicion = 90;
                if (ejercicio ==0){
                    condicion = 90;
                }
                else{
                    condicion = 50;
                }
                boolean isButtonEnabled2 = (length_angulo == 2)&&(Integer.valueOf(inputText2)<=condicion);
                Accept_btn.setEnabled(isButtonEnabled2);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        Accept_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String angulo_ingresado = "e"+ang_meta.getText().toString()+"f";
                String id_ext = "a"+ID+"b";
                metaView.setText(ang_meta.getText().toString());
                blue.bluTx(angulo_ingresado); // Senvía el angulo meta con los codigos iniciales y finales correspondientes para que el teensy los reconzca
                try {
                    // Pausa de 2 segundos (2000 milisegundos)
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    // Maneja la excepción si ocurre
                    e.printStackTrace();
                }
                blue.bluTx(id_ext); // Senvía el ID con los codigos iniciales y finales correspondientes para que el teensy los reconozca

                try {
                    // Pausa de 2 segundos (2000 milisegundos)
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    // Maneja la excepción si ocurre
                    e.printStackTrace();
                }
                blue.bluTx(nombre);

                try {
                    // Pausa de 2 segundos (2000 milisegundos)
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    // Maneja la excepción si ocurre
                    e.printStackTrace();
                }

                Accept_btn.setVisibility(View.GONE);
                ang_meta.setVisibility(View.GONE);
                Accept_btn2.setVisibility(View.VISIBLE);
                Resorte.setVisibility(View.VISIBLE);
                angulotxt.setVisibility(View.GONE);
                resortetxt.setVisibility(View.VISIBLE);

            }
        });

        Accept_btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String resorte_utilizado = "g"+Resorte.getText().toString()+"h";
                blue.bluTx(resorte_utilizado);
                Accept_btn2.setVisibility(View.GONE);
                Resorte.setVisibility(View.GONE);
                carro.setVisibility(View.VISIBLE);
                start.setVisibility(View.VISIBLE); // Se enciende botón de regresar
                consola.setVisibility(View.VISIBLE); // Se enciende el text view donde se ven los datos
                resortetxt.setVisibility(View.GONE);

            }
        });


        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                blue.bluTx("c");
                start.setVisibility(View.GONE);
                stop.setVisibility(View.VISIBLE);
                repView.setVisibility(View.VISIBLE);
                repTxt.setVisibility(View.VISIBLE);
                metaView.setVisibility(View.VISIBLE);
                metaTxt.setVisibility(View.VISIBLE);
                porcentView.setVisibility(View.VISIBLE);
                porcentTxt.setVisibility(View.VISIBLE);
            }
        });


        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                blue.bluTx("d");
                start.setVisibility(View.GONE);
                stop.setVisibility(View.GONE);
                buttonSend.setVisibility(View.VISIBLE);
            }
        });

        flex_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                blue.bluTx("p");
                izq_btn.setEnabled(true);
                der_btn.setEnabled(true);
                ext_btn.setVisibility(View.GONE);
                flex_btn.setVisibility(View.GONE);
                ejercicio = 0;
            }
        });
        ext_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                blue.bluTx("q");
                izq_btn.setEnabled(true);
                der_btn.setEnabled(true);
                ext_btn.setVisibility(View.GONE);
                flex_btn.setVisibility(View.GONE);
                ejercicio =1;

            }
        });

        izq_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                blue.bluTx("y");
                izq_btn.setVisibility(View.GONE);
                der_btn.setVisibility(View.GONE);
                ext_btn.setVisibility(View.GONE);
                flex_btn.setVisibility(View.GONE);
                brazotxt.setVisibility(View.GONE);
                Accept_btn.setVisibility(View.VISIBLE);
                ang_meta.setVisibility(View.VISIBLE);
                angulotxt.setVisibility(View.VISIBLE);

            }
        });
        der_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                blue.bluTx("x");
                izq_btn.setVisibility(View.GONE);
                der_btn.setVisibility(View.GONE);
                ext_btn.setVisibility(View.GONE);
                flex_btn.setVisibility(View.GONE);
                brazotxt.setVisibility(View.GONE);
                Accept_btn.setVisibility(View.VISIBLE);
                ang_meta.setVisibility(View.VISIBLE);
                angulotxt.setVisibility(View.VISIBLE);

            }
        });

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GlobalClass.id = ID;
                GlobalClass.nombre = nombre;
                blue.closeConnection(); // Se cierra la conexión BT

                // Crear un Intent y agregar los datos como "extras"
                Intent intent = new Intent(JuegoFlexion.this, Menu.class);
                intent.putExtra("id_env", GlobalClass.id);
                intent.putExtra("nombre_env", GlobalClass.nombre);
                intent.putExtra("habil", 1);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);


            }
        });


// ************************************INICIO DE BLUETOOTH********************************************************************************************* //
        // Se conecta el modulo:

        listDeviceBluetooth.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (!devicesBluetooth.isEmpty()){
                    blue.connect(devicesBluetooth.get(i));
                    blue.setDataLoadFinishedListener(new BluJhr.ConnectedBluetooth() {
                        @Override
                        public void onConnectState(@NonNull BluJhr.Connected connected) {
                            if (connected == BluJhr.Connected.True){
                                Toast.makeText(getApplicationContext(),"Conectado",Toast.LENGTH_SHORT).show();
                                listDeviceBluetooth.setVisibility(View.GONE); // Se apaga el listview
                                izq_btn.setVisibility(View.VISIBLE);
                                der_btn.setVisibility(View.VISIBLE);
                                flex_btn.setVisibility(View.VISIBLE);
                                ext_btn.setVisibility(View.VISIBLE);
                                brazotxt.setVisibility(View.VISIBLE);

                                RecibirDatos();
                            }else{
                                if (connected == BluJhr.Connected.Pending){
                                    Toast.makeText(getApplicationContext(),"Conectando",Toast.LENGTH_SHORT).show();
                                }else{
                                    if (connected == BluJhr.Connected.False){
                                        Toast.makeText(getApplicationContext(),"No se pudo conectar, intente de nuevo",Toast.LENGTH_SHORT).show();
                                    }else{
                                        if (connected == BluJhr.Connected.Disconnect){
                                            Toast.makeText(getApplicationContext(),"Desconectado",Toast.LENGTH_SHORT).show();
                                            listDeviceBluetooth.setVisibility(View.VISIBLE);
                                            viewConn.setVisibility(View.GONE);
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            }
        });


    }

    // Se piden permisos BT para Android 12 o más y para poder guardar archivos
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (blue.checkPermissions(requestCode,grantResults)){
            Toast.makeText(this, "Exit", Toast.LENGTH_SHORT).show();
            blue.initializeBluetooth();
        }else{
            if(Build.VERSION.SDK_INT < Build.VERSION_CODES.S){
                blue.initializeBluetooth();
            }else{
                Toast.makeText(this, "Algo salio mal", Toast.LENGTH_SHORT).show();
            }
        }

        if (requestCode == REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            } else {
                Toast.makeText(this, "Permiso de escritura en almacenamiento externo denegado", Toast.LENGTH_SHORT).show();
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    // Captura si el usuario dio o no permiso para prender el BT
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (!blue.stateBluetoooth() && requestCode == 100){
            blue.initializeBluetooth();
        }else{
            if (requestCode == 100){
                devicesBluetooth = blue.deviceBluetooth();
                if (!devicesBluetooth.isEmpty()){
                    ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_expandable_list_item_1,devicesBluetooth);
                    listDeviceBluetooth.setAdapter(adapter); // Se conecta el dispositivo
                }else{
                    Toast.makeText(this, "No tienes vinculados dispositivos", Toast.LENGTH_SHORT).show();
                }

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void ControlDatos(){
        blue.bluTx("c");


    }

    // Recibir datos
    private void RecibirDatos() {
        blue.loadDateRx(new BluJhr.ReceivedData() {
            @Override
            public void rxDate(@NonNull String s) {
                try{
                    consola.setText(s);

                    if ((Integer.valueOf(s)>10)&&(habilitador_reps == 0)){

                        habilitador_reps = 1;
                    }

                    if ((habilitador_reps == 1)&&(angulo_mayor_reps<=Integer.valueOf(s))){
                        angulo_mayor_reps = Integer.valueOf(s);
                    }

                    if ((Integer.valueOf(s)<3)&&(habilitador_reps==1)){
                        if (angulo_mayor_reps>=100){
                            rep_correctas = rep_correctas+1;
                        }
                        repView.setText(Integer.toString(rep_correctas));
                        habilitador_reps = 0;
                        angulo_mayor_reps = 0;
                    }


                    moveImage(Integer.valueOf(s));

                }
                catch (Exception e){
                    GlobalClass.dato = s;
                }

            }

        });

    }
// ************************************************FIN DE BLUETOOTH************************************************************** //



    //
    private void moveImage(int valor) {
        if (valor >100){
            porcentView.setText("100%");
        }
        else{
            porcentView.setText(Integer.toString(valor)+"%");
        }
        // Calcula la posición en X basada en el valor (0 a 100)
        float posX = (valor / 100f) * screenWidth;

        // Crea una animación para mover la imagen horizontalmente
        ObjectAnimator animator = ObjectAnimator.ofFloat(carro, "translationX", posX);
        animator.setDuration(800); // Duración de la animación en milisegundos
        animator.start();

    }



    // Para no poder utilizar el botón de atrás del teléfono:
    @Override
    public void onBackPressed(){
        Toast.makeText(JuegoFlexion.this," Función no permitida, favor utilizar el botón de regresar",Toast.LENGTH_SHORT).show();
    }



}

