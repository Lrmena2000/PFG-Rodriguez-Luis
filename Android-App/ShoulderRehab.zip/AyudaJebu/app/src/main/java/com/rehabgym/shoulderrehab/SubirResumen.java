package com.rehabgym.shoulderrehab;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;


import android.app.Activity;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


import java.io.InputStream;
import java.io.InputStreamReader;

public class SubirResumen extends AppCompatActivity {

    String MaximoAngulo;
    String MaximaFuerza;
    String TotalRepeticiones;
    String RepeticionesCorrectas;
    String IDDocumento;
    private ProgressDialog progressDialog;


    private static final int PICK_CSV_FILE = 1;
    String local_id;
    String local_name;

    private TextView welcomeMessage;
    private Button btnCheckInternet;
    private Button uploadbtn;
    private Button uploadbtn2;
    private Button menubtn;

    private OkHttpClient client;
    private String apiKey = "QQ0SAAFMLZRLPHKA";
    private String baseUrl = "https://api.thingspeak.com/channels";
    private String channelToCheck; // Declarar la variable aquí
    private int channel_ID = 0;

    private String WRITE_API_KEY = "M01HNB06P62F69D8";
    private String fieldToUpdate = "1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subir_resumen);

        Intent intent2 = getIntent();
        if (intent2 != null) {
            local_name = getIntent().getStringExtra("nombre_env");
            local_id = getIntent().getStringExtra("id_env");

            GlobalClass.id = local_id;
            GlobalClass.nombre = local_name;
        }

        progressDialog = new ProgressDialog(this);

        // Abre el selector de archivos
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_CSV_FILE);
    }


    //************************************ Envío de datos ******************************************//
    private void enviarDatos(String datoField1, String datoField2, String datoField3, String datoField4, String datoField5, String datoField6, String datoField7, String datoField8, boolean actualizarPrimerosCampos) {
        Toast.makeText(SubirResumen.this, "Archivo subido exitosamente", Toast.LENGTH_LONG).show();
        String url = "https://api.thingspeak.com/update";
        String apiKeyParam = "api_key=" + WRITE_API_KEY;;

        String fieldsParam;
        if (actualizarPrimerosCampos) {
            fieldsParam = String.format("field1=%s&field2=%s&field3=%s&field4=%s", datoField1, datoField2, datoField3, datoField4);
        } else {
            fieldsParam = String.format("field5=%s&field6=%s&field7=%s&field8=%s", datoField5, datoField6, datoField7, datoField8);
        }

        url = url + "?" + apiKeyParam + "&" + fieldsParam;

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String responseBody = response.body().string();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                        }
                    });
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                        }
                    });
                }
            }
        });
    }

    //*************************** Manejo de archivos CSV ******************************************//

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_CSV_FILE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Uri selectedFileUri = data.getData();
                if (selectedFileUri != null) {
                    try {
                        InputStream inputStream = getContentResolver().openInputStream(selectedFileUri);
                        if (inputStream != null) {
                            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                            StringBuilder columnData = new StringBuilder();

                            // Skip the first row (header)
                            reader.readLine();

                            String line;
                            int rowCounter = 0;
                            while ((line = reader.readLine()) != null && rowCounter < 2) {
                                String[] columns = line.split(",");
                                if (columns.length >= 8) {

                                    MaximoAngulo = columns[3];
                                    MaximaFuerza = columns[4];
                                    TotalRepeticiones = columns[5];
                                    RepeticionesCorrectas = columns[6];
                                    IDDocumento = columns[7];

                                }
                                rowCounter++;
                            }



                            inputStream.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }


        if (Integer.parseInt(IDDocumento) == 0){
            String datoField1 = MaximoAngulo;
            String datoField2 = MaximaFuerza;
            String datoField3 = TotalRepeticiones;
            String datoField4 = RepeticionesCorrectas;

            enviarDatos(datoField1, datoField2, datoField3, datoField4, null, null, null, null, true);

            Toast.makeText(SubirResumen.this, "Archivo subido exitosamente", Toast.LENGTH_LONG).show();

            // Manejar el caso en el que el usuario no selecciona un archivo y cerrar la actividad si es necesario.
            // Crear un Intent y agregar los datos como "extras"
            Intent intent = new Intent(SubirResumen.this, ManejoDatos.class);
            intent.putExtra("id_env", GlobalClass.id);
            intent.putExtra("nombre_env", GlobalClass.nombre);
            intent.putExtra("habil", 1);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);


        }

        else{
            String datoField5 = MaximoAngulo;
            String datoField6 = MaximaFuerza;
            String datoField7 = TotalRepeticiones;
            String datoField8 = RepeticionesCorrectas;

            enviarDatos(null, null, null, null, datoField5, datoField6, datoField7, datoField8, false);

            Toast.makeText(SubirResumen.this, "Archivo subido exitosamente", Toast.LENGTH_LONG).show();

            // Manejar el caso en el que el usuario no selecciona un archivo y cerrar la actividad si es necesario.
            // Crear un Intent y agregar los datos como "extras"
            Intent intent = new Intent(SubirResumen.this, ManejoDatos.class);
            intent.putExtra("id_env", GlobalClass.id);
            intent.putExtra("nombre_env", GlobalClass.nombre);
            intent.putExtra("habil", 1);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
        //
    }
}