
package layout.ayudajebu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.rehabgym.shoulderrehab.R;

public class JuegoCompresion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego_compresion);
    }
}