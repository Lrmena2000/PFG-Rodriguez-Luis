package com.rehabgym.shoulderrehab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Menu extends AppCompatActivity {

    // Elementos a utilizar en la ventana:
    Button extension_btn;
    Button flexion_btn;
    Button exit_btn;
    Button data_btn;
    Button inst_btn;
    Button upload_btn;

    int habilitador;

    String nombre;
    String ID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Crear la ventana y ocultar la barra de navegación
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        // Emepezar a correr la ventana:
        setContentView(R.layout.activity_menu);



        // Obtener los datos enviados por el Intent
        Intent intent = getIntent();
        if (intent != null) {
            habilitador = getIntent().getIntExtra("habil", 0);
            nombre = getIntent().getStringExtra("nombre_env");
            ID = getIntent().getStringExtra("id_env");
        }

        // Elementos dentro de la ventana que se crean al crear la ventana:
        extension_btn = (Button) findViewById(R.id.extension_btn);
        flexion_btn = (Button) findViewById(R.id.flexion_btn);
        exit_btn = (Button) findViewById(R.id.exit_btn);
        data_btn = (Button) findViewById(R.id.data_btn);
        inst_btn = (Button) findViewById(R.id.inst_btn);
        upload_btn = (Button) findViewById(R.id.upload_btn);



        if (habilitador == 0){
            extension_btn.setEnabled(false);
            flexion_btn.setEnabled(false);
            upload_btn.setEnabled(false);
        }
        else{
            extension_btn.setEnabled(true);
            flexion_btn.setEnabled(true);
            upload_btn.setEnabled(true);
        }

        // Acciones de los elementos:
        upload_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    GlobalClass.id = ID;
                    GlobalClass.nombre = nombre;
                    Intent i = new Intent(Menu.this,ManejoDatos.class);
                    i.putExtra("id_env", GlobalClass.id);
                    i.putExtra("nombre_env", GlobalClass.nombre);
                    startActivity(i);


            }
        });

        extension_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GlobalClass.id = ID;
                GlobalClass.nombre = nombre;
                Intent i = new Intent(Menu.this,JuegoExtension.class);
                i.putExtra("id_env", GlobalClass.id);
                i.putExtra("nombre_env", GlobalClass.nombre);
                startActivity(i);
            }
        });

        flexion_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GlobalClass.id = ID;
                GlobalClass.nombre = nombre;
                Intent i = new Intent(Menu.this,JuegoFlexion.class);
                i.putExtra("id_env", GlobalClass.id);
                i.putExtra("nombre_env", GlobalClass.nombre);
                startActivity(i);
            }
        });

        exit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });

        data_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Menu.this,IngresoDatos.class);
                startActivity(i);
            }
        });

        inst_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GlobalClass.id = ID;
                GlobalClass.nombre = nombre;
                Intent i = new Intent(Menu.this,MenuPrueba.class);
                i.putExtra("id_env", GlobalClass.id);
                i.putExtra("nombre_env", GlobalClass.nombre);
                startActivity(i);
            }
        });


    }

    // Para no poder utilizar el botón de atrás del teléfono:
    @Override
    public void onBackPressed(){
        Toast.makeText(Menu.this," Función no permitida, favor utilizar el botón de salir",Toast.LENGTH_SHORT).show();
    }

}