package layout.ayudajebu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.rehabgym.shoulderrehab.R;

public class MainActivity extends AppCompatActivity {
    // Elementos a utilizar en la ventana:
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Crear la ventana y ocultar la barra de navegación
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        // Emepezar a correr la ventana:
        setContentView(R.layout.activity_main);

        // Elementos dentro de la ventana que se crean al crear la ventana:
        button = (Button) findViewById(R.id.button);

        // Acciones de los elementos:
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Se cierran todas la ventanas y se vuelve al menu:
                Intent intent = new Intent(getApplicationContext(), Menu.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish(); // Se cierra la actividad actual
            }
        });

    }

    // Para no poder utilizar el botón de atrás del teléfono:
    @Override
    public void onBackPressed(){
        Toast.makeText(MainActivity.this," Función no permitida, favor utilizar el botón de salir",Toast.LENGTH_SHORT).show();
    }
}

