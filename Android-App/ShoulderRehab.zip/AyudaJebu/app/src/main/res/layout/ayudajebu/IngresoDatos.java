package layout.ayudajebu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;


import com.rehabgym.shoulderrehab.R;


public class IngresoDatos extends AppCompatActivity {

    // Elementos a utilizar:
    private static final int REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE = 1; // Para manejar los permisos de escritura
    private int length = 9;
    private int length_name = 0;
    private int length_id = 0;
    Button accept_btn;
    CheckBox foreign_btn;
    EditText id_txt;
    EditText name_txt;
    Button return_btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Crear la ventana y ocultar la barra de navegación
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);


        // Se crea la ventana:
        setContentView(R.layout.activity_ingreso_datos);


        // Objetos pertenecientes a la pantalla:
        accept_btn = (Button) findViewById(R.id.accept_btn);
        foreign_btn = (CheckBox) findViewById(R.id.foreign_btn);
        id_txt = (EditText) findViewById(R.id.voltage_txt);
        name_txt = (EditText) findViewById(R.id.angle_txt);
        return_btn = (Button) findViewById(R.id.return_btn);

        // Acciones de los objetos:
        // Botón de aceptar datos
        accept_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Se guardan los datos de los editText:
                String nombre1 = name_txt.getText().toString();
                String id1 = id_txt.getText().toString();

                // Se guardan los valores en las variables globales:
                GlobalClass.nombre = nombre1;
                GlobalClass.id = id1;

                // Se habilitan los ejercicios:
                GlobalClass.habilitador = 1;

                // Se cierran todas la ventanas y se vuelve al menu:
                Intent intent = new Intent(getApplicationContext(), Menu.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish(); // Se cierra la actividad actual

            }
        });
        // Botón de regresar:
        return_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Se cierran todas la ventanas y se vuelve al menu:
                Intent intent = new Intent(getApplicationContext(), Menu.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish(); // Se cierra la actividad actual
            }
        });

        // Botón de personas extranjeras:
        foreign_btn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            // Si el botón está oprimido, se espera un ID de 12 digitos, sino uno de 9
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                id_txt.getText().clear();
                if (foreign_btn.isChecked()) {
                    id_txt.setFilters(new InputFilter[]{new InputFilter.LengthFilter(12)});
                    length = 12;
                } else {
                    id_txt.setFilters(new InputFilter[]{new InputFilter.LengthFilter(9)});
                    length = 9;
                }
            }
        });

        // Cuadros de ingreso: Si no se cumplen las condiciones de nombre y ID correctos, no se habilita el botón de aceptar
        // Cuadro de ingreso de nombre:
        name_txt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                String inputText1 = s.toString();
                length_name = inputText1.length();
                boolean isButtonEnabled1 = (length_name != 0) && (length_id == length);
                accept_btn.setEnabled(isButtonEnabled1);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        // Cuadro de ingreso de ID:
        id_txt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence n, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence n, int i, int i1, int i2) {

                String inputText2 = n.toString();
                length_id = inputText2.length();
                boolean isButtonEnabled2 = (length_name != 0) && (length_id == length);
                accept_btn.setEnabled(isButtonEnabled2);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });



    }

}
